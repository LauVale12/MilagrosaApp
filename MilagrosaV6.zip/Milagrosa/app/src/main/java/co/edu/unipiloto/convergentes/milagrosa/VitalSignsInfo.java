package co.edu.unipiloto.convergentes.milagrosa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.view.View;
import android.content.Intent;
import android.widget.AdapterView;

public class VitalSignsInfo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vital_signs_info);
        //Referenciar el toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ArrayAdapter<VitalSigns> listAdapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                VitalSigns.vitalSigns
        );
        ListView listVitalSigns = (ListView) findViewById(R.id.list_vitalSigns);
        listVitalSigns.setAdapter(listAdapter);

        //Crear el listener
        AdapterView.OnItemClickListener itemClickListener =
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> listVitalSigns,
                                            View itemView,
                                            int position,
                                            long id) {
                        //Pasar el signo vital cuando el usuario clickea
                        Intent intent = new Intent(VitalSignsInfo.this, VSinfo.class);
                        intent.putExtra(VSinfo.EXTRA_VITALSID, (int) id);
                        startActivity(intent);
                    }
                };
        listVitalSigns.setOnItemClickListener(itemClickListener);
    }
}