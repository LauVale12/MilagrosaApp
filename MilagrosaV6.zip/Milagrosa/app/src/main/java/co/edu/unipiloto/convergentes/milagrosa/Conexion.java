package co.edu.unipiloto.convergentes.milagrosa;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Conexion extends SQLiteOpenHelper {

    //NOMBRE DE LA BASE
    private static final String NOMBRE_DB="milagrosa_DB";
    //VERSION PARA DIFERENCIAR EN CAMBIO DE HACER CAMBIOS A LA BASE
    private static final int VERSION_BD=3;
    //PARA GUARDAR EL SCRIPT DE CREAR TABLA PARA ALMACENAR DATOS
    private static final String TABLA_BASICINFO ="CREATE TABLE basicInfo(ID_basicInfo INTEGER PRIMARY KEY AUTOINCREMENT, patientName varchar (100)," +
            "userName varchar(100),"+
            "eMail varchar(100),"+
            "password varchar(100),"+
            "tSickness_1 varchar (100)," +
            "tSickness_2 varchar (100)," +
            "tSickness_3 varchar (100))";
    private static final String TABLA_PATIENTINFO = "CREATE TABLE patientInfo(ID_patientInfo INTEGER PRIMARY KEY AUTOINCREMENT," +
            "lvGlucosa float,aguVisual float,preArterial varchar(10)," +
            "frCardiaca INTEGER,tCorporal float,sintomas varchar(1000)," +
            "actFisica varchar(200),medicamentos varchar (200)," +
            "ID_basicInfo INTEGER, FOREIGN KEY(ID_basicInfo) REFERENCES basicInfo(ID_basicInfo))";
    private static final String TABLA_CALLAMBULANCE = "CREATE TABLE callAmbulance(" +
            "ID_callAmbulance INTEGER PRIMARY KEY AUTOINCREMENT,ubicacion varchar (100),"+
            "callAmbu INTEGER,ID_patientInfo INTEGER, FOREIGN KEY(ID_patientInfo) REFERENCES patientInfo(ID_patientInfo))";


    public Conexion(@Nullable Context context) {
        super(context, NOMBRE_DB, null, VERSION_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //para ejecutar sentencias
        sqLiteDatabase.execSQL(TABLA_BASICINFO);
        sqLiteDatabase.execSQL(TABLA_PATIENTINFO);
        sqLiteDatabase.execSQL(TABLA_CALLAMBULANCE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //para actualizaciones o conversiones de datos (BORRA LA VERSION ANTERIOR DE LA TABLA Y CREA UNA NUEVA)
        sqLiteDatabase.execSQL("DROP TABLE basicInfo");
        sqLiteDatabase.execSQL("DROP TABLE patientInfo");
        sqLiteDatabase.execSQL("DROP TABLE callAmbulance");
        sqLiteDatabase.execSQL(TABLA_BASICINFO);
        sqLiteDatabase.execSQL(TABLA_PATIENTINFO);
        sqLiteDatabase.execSQL(TABLA_CALLAMBULANCE);
    }

    public void initData(){
        SQLiteDatabase db = this.getWritableDatabase();
        onUpgrade(db, 1, 1);
    }

    //agrega los registros dentro de la tabla, se le asignan los parametros que se quieran agregar
    public boolean insertBasicInfo(String patientname, String uName, String email, String pass, String tsickness1, String tsickness2, String tsickness3){
        //initData();
        SQLiteDatabase db =getWritableDatabase();
        ContentValues inInfo = new ContentValues();
        inInfo.put("patientName", patientname);
        inInfo.put("userName", uName);
        inInfo.put("eMail", email);
        inInfo.put("password", pass);
        inInfo.put("tSickness_1", tsickness1);
        inInfo.put("tSickness_2", tsickness2);
        inInfo.put("tSickness_3", tsickness3);
        //insertar la información
        long result = db.insert("basicInfo", null, inInfo);
        if(result==-1){
            return false;
        } else {
            return true;
        }
    }

    public boolean insertpatientInfo(String lvglucosa, String aguvisual, String prearterial, String frcardiaca, String tcorporal, String sintoma, String actfisica, String medicamento, int id){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("lvGlucosa", lvglucosa);
        contentValues.put("aguVisual", aguvisual);
        contentValues.put("preArterial", prearterial);
        contentValues.put("frCardiaca", frcardiaca);
        contentValues.put("tCorporal", tcorporal);
        contentValues.put("sintomas", sintoma);
        contentValues.put("actFisica", actfisica);
        contentValues.put("medicamentos", medicamento);
        contentValues.put("ID_basicInfo", id);
        //Insertar datos
        long result = db.insert("patientInfo", null, contentValues);
        if(result==-1){
            return false;
        } else {
            return true;
        }
    }

    public boolean insertcallAmbulance(String ubicación, String callambu){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("ubicacion", ubicación);
        contentValues.put("callAmbu", callambu);
        //Introducir datos
        long result = db.insert("callAmbulance", null, contentValues);
        if(result==-1){
            return false;
        } else {
            return true;
        }
    }

    //Obtener la información
    public Cursor obtAllInfo(String tableName){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor result = db.rawQuery("select * from " +  tableName, null);
        return result;
    }

    //Obtener información de una fila
    public Cursor getData(String tableName, int id){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + tableName + " where ID_" + tableName + " =" + id + "", null);
        return res;
    }

    //Obtener información especifica
    public Cursor findDatabyAttribute(String tableName, String columna, String atributo){
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor res = db.rawQuery("select * from " + tableName + " where "+ columna +"= '"+ atributo +"'", null);
        return res;
    }



    //Actualizar la información
    public void actualizarInfo(String tabla, String columnas, String condicion){
        SQLiteDatabase db = getWritableDatabase();
        if (db!=null){
            db.execSQL("UPDATE '" + tabla + "' SET '" + columnas +"' WHERE '" + condicion + "' ");
        }
    }

}
