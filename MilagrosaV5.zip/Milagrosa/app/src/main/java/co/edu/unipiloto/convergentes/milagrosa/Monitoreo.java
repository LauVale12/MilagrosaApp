package co.edu.unipiloto.convergentes.milagrosa;

import android.database.Cursor;

import java.util.ArrayList;
import java.util.List;

public class Monitoreo {

    private int userId;

    public Monitoreo(){

    }

    public List<String> EvalVitalSigns(String lvglucosa, String aguvisual, String prearterial, String frcardiaca, String tcorporal){
        List<String> lista = new ArrayList<>();
        int glucosa = Integer.parseInt(lvglucosa);
        if (glucosa>=70 || glucosa<=100){
            lista.add("normal");
        }else {
            lista.add("anormal");
        }
        float aguV = Float.parseFloat(aguvisual);
        if (aguV>=0.8 || aguV <= 1.5){
            lista.add("normal");
        }else{
            lista.add("anormal");
        }
        String[] parts = prearterial.split("/");
        int preSis = Integer.parseInt(parts[0]);
        int preDis = Integer.parseInt(parts[1]);
        if (preSis<=120 && preDis<=80){
            lista.add("normal");
        }else {
            lista.add("anormal");
        }
        int frecar = Integer.parseInt(frcardiaca);
        if (frecar<=100 && frecar>=60){
            lista.add("normal");
        }else {
            lista.add("anormal");
        }
        float tcorp = Float.parseFloat(tcorporal);
        if (tcorp<37.7 && tcorp>35){
            lista.add("normal");
        }else {
            lista.add("anormal");
        }
        return lista;
    }
}
