package co.edu.unipiloto.convergentes.milagrosa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //Variables
    public static final String EXTRA_REPLY = "message";
    static int userId;
    Conexion conexion;
    EditText usuario;
    EditText contraseña;
    Button registrar;
    Button entrar;
    boolean confP;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userId = 1;
        conexion=new Conexion(getApplicationContext()); //para usar los metodos que conforman la clase
        usuario = (EditText)findViewById(R.id.edUser);
        contraseña = (EditText)findViewById(R.id.edPassW);
        registrar =(Button)findViewById(R.id.registro);
        entrar = (Button)findViewById(R.id.login);
        confP = false;

        //Obtener la información de la base de datos


        registrar.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, Registro.class);
                startActivity(intent);

            }
        });

        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                confContraseña();
                if (confP) {
                    Intent i = new Intent(MainActivity.this, IngresoDeDatos.class);
                    //Enviar el Id que se esta usando
                    i.putExtra(IngresoDeDatos.EXTRA_MESSAGE, userId);
                    startActivity(i);
                }
            }

        });





    }

    private void confContraseña() {
        String uName = usuario.getText().toString();
        String contI = contraseña.getText().toString();
        String contE = "";
        if(!uName.isEmpty() && !contI.isEmpty()){
            Cursor res = conexion.findDatabyAttribute("basicInfo", "userName", uName);
            if (res.moveToFirst()){
                userId = Integer.parseInt(res.getString(0));
                contE = res.getString(4);
                if (contI.equals(contE)){
                    confP = true;
                }
            }

        }else{
            Toast.makeText(getApplicationContext(), "Debes introducir el usuario y contraseña", Toast.LENGTH_SHORT).show();
            confP = false;
        }
    }


}

