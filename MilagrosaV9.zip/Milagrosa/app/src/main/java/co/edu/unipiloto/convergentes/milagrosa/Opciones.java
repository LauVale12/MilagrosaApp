package co.edu.unipiloto.convergentes.milagrosa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Opciones extends AppCompatActivity {
    public static final String EXTRA_UID = "messageOP";
    Button btPedirAmbu, btDesplaza;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_opciones);

        btPedirAmbu = (Button) findViewById(R.id.btPedirAmbu);
        btDesplaza = (Button) findViewById(R.id.btDesplazar);
        //pedir el id
        int id_default = 1;
        Intent intentId = getIntent();
        int uId = intentId.getIntExtra(EXTRA_UID, id_default);

        btPedirAmbu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Opciones.this, Ubicacion.class);
                intent.putExtra(Ubicacion.EXTRA_ID, uId);
                startActivity(intent);
            }
        });

        btDesplaza.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(Opciones.this, Desplazamiento.class);
                startActivity(intent1);
            }
        });

    }
}