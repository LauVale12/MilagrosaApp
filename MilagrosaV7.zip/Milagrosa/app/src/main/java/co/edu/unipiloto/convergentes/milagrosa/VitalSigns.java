package co.edu.unipiloto.convergentes.milagrosa;

public class VitalSigns {
    private String name;
    private String description;

    private VitalSigns(String nombre, String desc){
        name = nombre;
        description = desc;
    }

    public static final VitalSigns[] vitalSigns = {
            new VitalSigns("Glucosa", "Un rango normal para el azúcar en la sangre en ayunas,"
            + "está entre 70 a 100 mg/dl"),
            new VitalSigns("Agudeza Visual", "Es la capacidad del ojo para reconocer la forma"
            + "de los objetos e identificar las imágenes que /n llegan a través del nervio optico a nuestro cerebro"),
            new VitalSigns("Presion arterial", "Es la fuerza que la sangre ejerce contra las paredes arteriales"),
            new VitalSigns("Frecuencia cardiaca", "Normalmente el corazón late entre 60 y 100 veces por minuto"),
            new VitalSigns("Temperatura corporal", "Es una medida de la capacidad que tiene el cuerpo"
            +"para producir y deshacerse del calor")
    };

    public String getDescription() {
        return description;
    }

    public String getName() {
        return name;
    }

    public String toString(){
        return this.name;
    }
}

