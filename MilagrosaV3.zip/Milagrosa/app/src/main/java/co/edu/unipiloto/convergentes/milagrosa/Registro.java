package co.edu.unipiloto.convergentes.milagrosa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;


public class Registro extends AppCompatActivity {

    EditText edNombre;
    Spinner spEnf_1;
    Spinner spEnf_2;
    Spinner spEnf_3;
    Button btNext;
    //para usar los metodos que conforman la clase
    Conexion conexion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);


        //Inicializar la variables
        conexion =new Conexion(this);
        edNombre=(EditText)findViewById(R.id.name);
        spEnf_1=(Spinner)findViewById(R.id.enfermedad);
        spEnf_2=(Spinner)findViewById(R.id.enfermedad2);
        spEnf_3=(Spinner)findViewById(R.id.enfermedad3);
        btNext=(Button)findViewById(R.id.next);

        //Conseguir la información de los Spinners
        String enf1 = spEnf_1.getItemAtPosition(spEnf_1.getSelectedItemPosition()).toString();
        String enf2 = spEnf_2.getItemAtPosition(spEnf_2.getSelectedItemPosition()).toString();
        String enf3 = spEnf_3.getItemAtPosition(spEnf_3.getSelectedItemPosition()).toString();

        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean IsInserted = conexion.insertBasicInfo(edNombre.getText().toString(),enf1, enf2, enf3);
                if(IsInserted){
                    Toast.makeText(getApplicationContext(),"se agrego correctamente",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getApplicationContext(),"No se logro agregar",Toast.LENGTH_SHORT).show();
                }

                Intent intent = new Intent(Registro.this, IngresoDeDatos.class);
                startActivity(intent);

            }
        });
    }


}