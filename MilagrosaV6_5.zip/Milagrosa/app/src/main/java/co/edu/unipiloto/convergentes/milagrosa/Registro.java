package co.edu.unipiloto.convergentes.milagrosa;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;


public class Registro extends AppCompatActivity {

    public static final String EXTRA_MESSAGE = "message";
    EditText edNombre;
    EditText edUser;
    EditText edMail;
    EditText edPass;
    EditText edPassC;
    Spinner spEnf_1;
    Spinner spEnf_2;
    Spinner spEnf_3;
    RadioGroup radioButtonGroup;

    Button btNext;
    //para usar los metodos que conforman la clase
    Conexion conexion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);


        //Inicializar la variables
        conexion =new Conexion(this);
        edNombre=(EditText)findViewById(R.id.name);
        edUser = (EditText)findViewById(R.id.user);
        edMail = (EditText)findViewById(R.id.eMail);
        edPass = (EditText)findViewById(R.id.passw);
        edPassC = (EditText)findViewById(R.id.passwC);
        spEnf_1=(Spinner)findViewById(R.id.enfermedad);
        spEnf_2=(Spinner)findViewById(R.id.enfermedad2);
        spEnf_3=(Spinner)findViewById(R.id.enfermedad3);
        radioButtonGroup= (RadioGroup) findViewById(R.id.radioG);
        btNext=(Button)findViewById(R.id.next);


        //Conseguir el radio boton presionado
        int radioBId = radioButtonGroup.getCheckedRadioButtonId();
        View radioBoton = radioButtonGroup.findViewById(radioBId);
        int indice = radioButtonGroup.indexOfChild(radioBoton);
        //Conseguir el texto del radio Boton



        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Conseguir la información de los Spinners
                String enf1 = spEnf_1.getItemAtPosition(spEnf_1.getSelectedItemPosition()).toString();
                String enf2 = spEnf_2.getItemAtPosition(spEnf_2.getSelectedItemPosition()).toString();
                String enf3 = spEnf_3.getItemAtPosition(spEnf_3.getSelectedItemPosition()).toString();

                //Confirmar que las contraseñas sean iguales
                String contra =  edPass.getText().toString();
                String contraC = edPassC.getText().toString();

                if (confPass(contra, contraC)){
                    boolean IsInserted = conexion.insertBasicInfo(edNombre.getText().toString(), edUser.getText().toString(), edMail.getText().toString(),
                            contra ,enf1, enf2, enf3);
                    if(IsInserted){
                        Toast.makeText(getApplicationContext(),"se agrego correctamente",Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(getApplicationContext(),"No se logro agregar",Toast.LENGTH_SHORT).show();
                    }

                    Intent intent = new Intent(Registro.this, IngresoDeDatos.class);
                    //Enviar el id que se esta usando
                    int uId = getUserId(edUser.getText().toString());
                    intent.putExtra(IngresoDeDatos.EXTRA_MESSAGE,uId);
                    startActivity(intent);
                }else {
                    Toast.makeText(getApplicationContext(), "Las dos contraseñas deben ser iguales", Toast.LENGTH_SHORT).show();
                }


            }
        });

    }

    public boolean confPass(String cont1, String cont2){
        if (cont1.equals(cont2)){
            return true;
        }else {
            return false;
        }
    }
    public int getUserId(String uName){
        if (!uName.isEmpty()){
            Cursor res = conexion.findDatabyAttribute("basicInfo", "userName", uName);
            if (res.moveToFirst()){
                int uId = Integer.parseInt(res.getString(0));
                return uId;
            }
        }
        return -1;
    }


}