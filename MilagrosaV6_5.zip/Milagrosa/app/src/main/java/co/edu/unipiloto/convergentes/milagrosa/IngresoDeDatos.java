package co.edu.unipiloto.convergentes.milagrosa;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

public class IngresoDeDatos extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "message";
    Conexion conexion;
    TextView teGlucosa, teAguVisual, tePreArterial, teFreCardiac, texTempCorp, teSint, teActFis, teMedic;
    EditText edGlucosa, edAguVisual, edPreArterial, edFreCardiac, edTempCorp, edSint, edActFis, edMedic;
    Button btenviar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Inicializar las variables
        setContentView(R.layout.activity_ingreso_de_datos);
        conexion = new Conexion(this);
        teGlucosa = (TextView) findViewById(R.id.glucosa);
        edGlucosa = (EditText) findViewById(R.id.editGlucosa);
        teAguVisual = (TextView) findViewById(R.id.aguVisual);
        edAguVisual = (EditText) findViewById(R.id.editAguVisual);
        tePreArterial = (TextView) findViewById(R.id.preArt);
        edPreArterial = (EditText) findViewById(R.id.editPreArt);
        teFreCardiac = (TextView) findViewById(R.id.freCard);
        edFreCardiac = (EditText) findViewById(R.id.editFreCard);
        texTempCorp = (TextView) findViewById(R.id.tCorp);
        edTempCorp = (EditText) findViewById(R.id.editTCorp);
        teSint = (TextView) findViewById(R.id.sint);
        edSint = (EditText) findViewById(R.id.editSint);
        teActFis = (TextView) findViewById(R.id.actFis);
        edActFis = (EditText) findViewById(R.id.editActFis);
        teMedic = (TextView) findViewById(R.id.medi);
        edMedic = (EditText) findViewById(R.id.editMedi);
        btenviar = (Button) findViewById(R.id.enviarD);
        //Valor por defecto
        int id_default = 1;

        //Referenciar el toolbar
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        //Obtener el Id
        Intent intent = getIntent();
        /*String messageText = intent.getStringExtra(EXTRA_MESSAGE);
        int uId = Integer.parseInt(messageText);*/
        int uId = intent.getIntExtra(EXTRA_MESSAGE, id_default);
        if (uId>=0){
            List<String> lista = obtenerInfoBasic(uId);
            actualizarVistas(lista);
        }else {
            List<String> lista = obtenerInfoBasic(1);
        }


        
        //Para cuando no sirve la base de datos
        /*ArrayList<String> lista = new ArrayList<>();
        lista.add("ninguna");*/


        
        btenviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean IsInserted = conexion.insertpatientInfo(edGlucosa.getText().toString(), edAguVisual.getText().toString(),
                        edPreArterial.getText().toString(), edFreCardiac.getText().toString(), edTempCorp.getText().toString(),
                        edSint.getText().toString(), edActFis.getText().toString(), edMedic.getText().toString(), uId);
                if(IsInserted){
                    Toast.makeText(getApplicationContext(),"se agrego correctamente",Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getApplicationContext(),"No se logro agregar",Toast.LENGTH_SHORT).show();
                }


            }
        });


    }

    private List<String> obtenerInfoBasic(int id){
        List<String> lista = new ArrayList<>();
        Cursor res = conexion.findDatabyAttribute("basicInfo", "ID_basicInfo",id+"");
        if (res.moveToFirst()){
            lista.add(res.getString(5));
            lista.add(res.getString(6));
            lista.add(res.getString(7));
        }
        return lista;
    }

    public void actualizarVistas(List<String> lista){
        if (!lista.contains("Diabetes")){
            teGlucosa.setVisibility(View.GONE);
            edGlucosa.setVisibility(View.GONE);
            teAguVisual.setVisibility(View.GONE);
            edAguVisual.setVisibility(View.GONE);
            edGlucosa.setText("99");
            edAguVisual.setText("0.9");
        }
        if (!lista.contains("Hipertensión")) {
            tePreArterial.setVisibility(View.GONE);
            edPreArterial.setVisibility(View.GONE);
            edPreArterial.setText("120/80");
        }
        if (!lista.contains("insuficiencia cardiaca")) {
            teFreCardiac.setVisibility(View.GONE);
            edFreCardiac.setVisibility(View.GONE);
            edFreCardiac.setText("70");
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.action_ver_info:
                    Intent intent = new Intent(IngresoDeDatos.this, VitalSignsInfo.class);
                    startActivity(intent);
                    return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}