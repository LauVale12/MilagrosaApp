package co.edu.unipiloto.convergentes.milagrosa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class VSinfo extends AppCompatActivity {

    public static final String EXTRA_VITALSID = "vitalSignsId";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vsinfo);

        //Obtener el signo vital del intent
        int vitalSignsId = (Integer)getIntent().getExtras().get(EXTRA_VITALSID);
        VitalSigns vitalSigns = VitalSigns.vitalSigns[vitalSignsId];

        TextView nombre = (TextView)findViewById(R.id.VSname);
        nombre.setText(vitalSigns.getName());

        TextView description = (TextView) findViewById(R.id.VSdescription);
        description.setText(vitalSigns.getDescription());
    }

}