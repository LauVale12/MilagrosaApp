package co.edu.unipiloto.convergentes.milagrosa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Ubicacion extends AppCompatActivity {

    public static final String EXTRA_ID = "messageU";

    Conexion conexion;
    TextView verLatitud, verLongitud, verPais, verLocalidad, verDireccion;
    EditText direccion;
    Button btconf, btconfUbi, btLocalizar;
    FusedLocationProviderClient fusedLocationProviderClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ubicacion);
        conexion = new Conexion(this);
        verLatitud = (TextView) findViewById(R.id.verLatitud);
        verLongitud = (TextView) findViewById(R.id.verLongitud);
        verPais = (TextView) findViewById(R.id.verPais);
        verLocalidad = (TextView) findViewById(R.id.verLocalidad);
        verDireccion = (TextView) findViewById(R.id.verDireccion);
        direccion = (EditText) findViewById(R.id.edDireccion);
        btLocalizar = (Button) findViewById(R.id.Localizar);
        btconfUbi = (Button) findViewById(R.id.btConfDatosUbi);
        btconf = (Button) findViewById(R.id.btConfUbi);
        //Inicializamos la fusedLocalization
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        //Valor por defecto
        int id_default = 1;

        //Obtener el id
        Intent intent = getIntent();
        int uId = intent.getIntExtra(EXTRA_ID, id_default);

        //Obtener el id de la ultima informacion
        List<String> list = obtenerPatientInfo(uId);
        int pId = Integer.parseInt(list.get(list.size() - 1));

        //Buscar información
        btLocalizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                obtenerLocalizacion();

            }
        });

        btconfUbi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean IsInserted = conexion.insertcallAmbulance(verDireccion.getText().toString(), "1", pId + "");
                Intent intent1 = new Intent(Ubicacion.this, DelayedMessageService.class);
                intent1.putExtra(DelayedMessageService.EXTRA_MESSAGE, "Su ambulancia va en camino");
                if (IsInserted){
                    Toast.makeText(getApplicationContext(), "se agrego correctamente", Toast.LENGTH_SHORT).show();
                    startService(intent1);
                }else {
                    Toast.makeText(getApplicationContext(),"No se logro agregar",Toast.LENGTH_SHORT).show();
                }
            }
        });

        //Información ingresada
        btconf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Cuando se llegue a la parte de llamado de la ambulancia se utilizará un metodo para saber si se llamo
                String dir = direccion.getText().toString();
                //String mens = obtenerDatosDelPaciente(pId);
                String mens = "El paciente necesita ambulancia";

                boolean IsInserted = conexion.insertcallAmbulance(dir, "1", pId + "");
                Intent in = new Intent(Intent.ACTION_SENDTO);
                in.setData(Uri.parse("mailto:"));
                in.putExtra(Intent.EXTRA_EMAIL, "larravalentina2002@gmail.com");
                in.putExtra(Intent.EXTRA_SUBJECT, "Enviar Ambulancia");
                in.putExtra(Intent.EXTRA_TEXT, "dirección: "+ dir + mens);
                if (IsInserted) {
                    Toast.makeText(getApplicationContext(), "se agrego correctamente", Toast.LENGTH_SHORT).show();
                    //startActivity(in);
                } else {
                    Toast.makeText(getApplicationContext(), "No se logro agregar", Toast.LENGTH_SHORT).show();
                }


            }
        });
    }


    private void obtenerLocalizacion() {
        if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)  {

        fusedLocationProviderClient.getLastLocation().addOnCompleteListener(
                new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        Location location = task.getResult();
                        if (location != null) {
                            //Iniciar el convertidor Geocorder
                            Geocoder geo = new Geocoder(Ubicacion.this, Locale.getDefault());
                            try {
                                List<Address> listaDirecciones = geo.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                                verLatitud.setText(listaDirecciones.get(0).getLatitude() + "");
                                verLongitud.setText(listaDirecciones.get(0).getLongitude() + "");
                                verPais.setText(listaDirecciones.get(0).getCountryName() + "");
                                verLocalidad.setText(listaDirecciones.get(0).getLocality() + "");
                                verDireccion.setText(listaDirecciones.get(0).getAddressLine(0));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
        );
        }
    }

    public void onSendMaps(View view){
        Uri gmmIntentUri = Uri.parse("https://goo.gl/maps/9amiejbfYE4efoay5");
        Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
        mapIntent.setPackage("com.google.android.apps.maps");
        startActivity(mapIntent);
    }

    public List<String> obtenerPatientInfo(int userId){
        List<String> lista = new ArrayList<>();
        Cursor res = conexion.findDatabyAttribute("patientInfo", "ID_basicInfo", userId+"");
        while (res.moveToNext()){
            lista.add(res.getString(0));
        }
        return lista;
    }

    public String obtenerDatosDelPaciente(int patientId){
        String mensaje = "";
        Cursor res = conexion.findDatabyAttribute("patientInfo", "ID_patientInfo", patientId+"");
        while (res.moveToFirst()){
            mensaje+= "niveles de glucosa: " + res.getString(1) + "\n";
            mensaje+= "Agudeza Visual: " +res.getString(2) +"\n";
            mensaje+= "Presión Arterial: " + res.getString(3) + "\n";
            mensaje+= "Frecuencia cardiaca: " + res.getString(4) +"\n";
            mensaje+= "Temperatura corporal: " + res.getString(5) + "\n";
            mensaje+= "Sintomas: " + res.getString(6) + "\n";
            mensaje+= "Actividad Fisica: " + res.getString(7) + "\n";
            mensaje+= "Medicamentos: " + res.getString(8) + "\n";
        }
        return mensaje;
    }
}