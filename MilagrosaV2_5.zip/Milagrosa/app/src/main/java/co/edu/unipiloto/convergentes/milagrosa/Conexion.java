package co.edu.unipiloto.convergentes.milagrosa;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Conexion extends SQLiteOpenHelper {

    //NOMBRE DE LA BASE
    private static final String NOMBRE_DB="milagrosa_DB";
    //VERSION PARA DIFERENCIAR EN CAMBIO DE HACER CAMBIOS A LA BASE
    private static final int VERSION_BD=1;
    //PARA GUARDAR EL SCRIPT DE CREAR TABLA PARA ALMACENAR DATOS
    private static final String TABLA_BASICINFO ="CREATE TABLE basicInfo(ID_BasicInfo int PRIMARY KEY AUTOINCREMENT, patientName varchar (100)," +
            "tSickness_1 varchar (100)," +
            "tSickness_2 varchar (100)," +
            "tSickness_3 varchar (100))";
    private static final String TABLA_PATIENTINFO = "CREATE TABLE patientInfo(ID_paInfo int PRIMARY KEY AUTOINCREMENT," +
            "lvGlucosa float,aguVisual float,preArterial int," +
            "frCardiaca int,tCorporal float,sintomas varchar(1000)," +
            "actFisica varchar(200),medicamentos varchar (200)," +
            "ID_BasicInfo int, FOREIGN KEY(ID_BasicInfo) REFERENCES basicInfo(ID_BasicInfo))";
    private static final String TABLA_CALLAMBULANCE = "CREATE TABLE callAmbulance(" +
            "ID_cAmbu int PRIMARY KEY AUTOINCREMENT,ubicacion varchar (100),"+
            "callAmbu int,ID_paInfo int, FOREIGN KEY(ID_paInfo) REFERENCES patientInfo(ID_paInfo))";


    public Conexion(@Nullable Context context) {
        super(context, NOMBRE_DB, null, VERSION_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //para ejecutar sentencias
        sqLiteDatabase.execSQL(TABLA_BASICINFO);
        sqLiteDatabase.execSQL(TABLA_PATIENTINFO);
        sqLiteDatabase.execSQL(TABLA_CALLAMBULANCE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //para actualizaciones o conversiones de datos (BORRA LA VERSION ANTERIOR DE LA TABLA Y CREA UNA NUEVA)
        sqLiteDatabase.execSQL("DROP TABLE basicInfo");
        sqLiteDatabase.execSQL("DROP TABLE patientInfo");
        sqLiteDatabase.execSQL("DROP TABLE callAmbulance");
        sqLiteDatabase.execSQL(TABLA_BASICINFO);
        sqLiteDatabase.execSQL(TABLA_PATIENTINFO);
        sqLiteDatabase.execSQL(TABLA_CALLAMBULANCE);
    }

    //agrega los registros dentro de la tabla, se le asignan los parametros que se quieran agregar
    public void insertBasicInfo(String patientname, String tsickness1, String tsickness2, String tsickness3){
        //para manipular la base en modo de lectura y escritura
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){ //confirmar si se abrio la base de modo correcto
            bd.execSQL("INSERT INTO basicInfo (patientName, tSickness_1, tSickness_2, tSickness_3) " +
                    "VALUES('"+ patientname +"','"+ tsickness1 +"','"+ tsickness2 +"','"+ tsickness3 +"')");
            bd.close();
        }
    }

    public void insertpatientInfo(String lvglucosa, String aguvisual, String prearterial, String frcardiaca, String tcorporal, String sintoma, String actfisica, String medicamento){
        //para manipular la base en modo de lectura y escritura
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){ //confirmar si se abrio la base de modo correcto
            bd.execSQL("INSERT INTO patientInfo(lvGlucosa, aguVisual, preArterial, frCardiaca, tCorporal, sintomas, actFisica, medicamentos) " +
                    "VALUES('"+ lvglucosa +"','"+ aguvisual +"','"+ prearterial +"','"+ frcardiaca +"','"+ tcorporal +"','"+ sintoma +"','"+ actfisica +"','"+ medicamento +"')");
            bd.close();
        }
    }

    public void insertcallAmbulance(String ubicación, String callambu){
        //para manipular la base en modo de lectura y escritura
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){ //confirmar si se abrio la base de modo correcto
            bd.execSQL("INSERT INTO callAmbulance(ubicacion, callAmbu) " +
                    "VALUES('"+ ubicación +"','"+ callambu +"')");
            bd.close();
        }
    }

    //Buscar información en las tablas
    public String seleccionarInfo(String columna, String tabla){
        String seleccion = "";
        SQLiteDatabase db = getReadableDatabase();
        if(db!=null){
            db.execSQL("SELECT '" + columna + "' FROM '" +tabla+"' " );
        }

        return seleccion;
    }

    //Actualizar la información
    public void actualizarInfo(String tabla, String columnas, String condicion){
        SQLiteDatabase db = getWritableDatabase();
        if (db!=null){
            db.execSQL("UPDATE '" + tabla + "' SET '" + columnas +"' WHERE '" + condicion + "' ");
        }
    }

}
