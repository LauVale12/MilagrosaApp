package co.edu.unipiloto.convergentes.milagrosa;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;


public class Registro extends AppCompatActivity {

    EditText edNombre;
    Spinner spEnf_1;
    Spinner spEnf_2;
    Spinner spEnf_3;
    Button btNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro);

        //para usar los metodos que conforman la clase
        final Conexion Conexion=new Conexion(getApplicationContext());
        //Inicializar la variables
        edNombre=(EditText)findViewById(R.id.name);
        spEnf_1=(Spinner)findViewById(R.id.enfermedad);
        spEnf_2=(Spinner)findViewById(R.id.enfermedad2);
        spEnf_3=(Spinner)findViewById(R.id.enfermedad3);
        btNext=(Button)findViewById(R.id.next);

        //Conseguir la información de los Spinners
        String enf1 = spEnf_1.getItemAtPosition(spEnf_1.getSelectedItemPosition()).toString();
        String enf2 = spEnf_2.getItemAtPosition(spEnf_2.getSelectedItemPosition()).toString();
        String enf3 = spEnf_3.getItemAtPosition(spEnf_3.getSelectedItemPosition()).toString();

        btNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Conexion.insertBasicInfo(edNombre.getText().toString(),enf1, enf2, enf3);
                Toast.makeText(getApplicationContext(),"se agrego correctamente",Toast.LENGTH_SHORT).show();

            }
        });
    }


}